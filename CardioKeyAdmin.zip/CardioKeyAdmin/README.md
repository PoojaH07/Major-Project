# CardioKey Admin — Android demo app

A minimal, end-to-end Jetpack Compose app implementing:
`Admin phone ↔ ESP32 (direct, for Wi-Fi provisioning + session commands)` and
`ESP32 → Flask/S3 (for recordings)`, with MQTT stubbed out (not built yet — see
"What's not here" below). UI styling follows the palette/layout of the HTML mockup
(`Setup`, `Enroll`, `Authenticate`, `Status`, `History` — mapped to the app's five tabs).

## Run it

1. Open the `CardioKeyAdmin/` folder in Android Studio (Iguana or newer) — **File → Open**,
   pick this folder (the one with `settings.gradle.kts` in it).
2. Let Gradle sync. First sync will download the Gradle 8.7 distribution referenced in
   `gradle/wrapper/gradle-wrapper.properties` — needs internet once.
3. Plug in an Android phone (or use an emulator with Wi-Fi networking, though the setup-AP
   flow only makes sense on a real phone) with USB debugging on, min SDK 26.
4. Click Run ▶ with the `app` module selected. The app installs and launches on the device.

No signing config is needed for a debug run; this is not set up for release/Play Store.

## Demo steps (with a real ESP32 running the current firmware)

1. **Setup tab, Stage 1** — Join the phone's Wi-Fi to `CardioKey-Setup-XXXX` (the ESP32's
   temporary AP). Tap "Check setup network." This calls `GET http://192.168.4.1/status`.
2. Enter your home Wi-Fi SSID/password, tap "Send to device." This calls
   `POST http://192.168.4.1/wifi/configure`. The device reboots onto your home network.
3. **Setup tab, Stage 2** — Rejoin your phone to your normal home Wi-Fi. Find the device's
   new IP (router client list or its OLED) and enter it, tap "Confirm device on home
   network." This calls `GET http://<device-ip>/status` — note this is a *different*
   network context than step 1, and the app's code keeps these two calls in separate
   Retrofit clients (`SetupApi` vs `DeviceApi`) on purpose.
4. Tap "Save and continue" — the device IP is now persisted (DataStore) and every other
   tab uses it.
5. **Enroll tab** — enter a user ID, tap "Start enrollment capture." Watch the states:
   Starting → Recording → Uploading → Enrollment recorded (or Upload failed). This exercises
   `POST /enroll/start` then polls `GET /session/{id}/status` until `upload_ok`/`upload_failed`.
6. **Authenticate tab** — tap "Start authentication capture." Same recording/upload flow,
   but the terminal state on success is **"Upload succeeded — result pending,"** not a
   match/no-match verdict — because the firmware doesn't expose `auth_result` yet. This is
   deliberate: the app never claims authentication succeeded just because the S3 upload did.
7. **Status tab** — pulls live `GET /status` from the device (state + wifi_connected).
8. **History tab** — tries `GET <backend>/history`; since no backend URL is configured yet
   in this build, it falls back to labeled mock data (a "Demo data" chip shows up, and
   `MockData.kt` is commented `// MOCK DATA` throughout).

## Demo steps if you don't have a device handy

Every screen degrades gracefully with clear error text if a call fails (e.g. "Can't reach
device at 192.168.4.1") rather than crashing, so you can walk through the UI states without
hardware — you'll just see the "Failed"/"Error" branches instead of the happy path.

## What's here vs. what's a stub

- **Real, wired up:** Setup (both stages), Enroll, Authenticate (including the
  upload-vs-auth distinction), Status, and a History screen with mock fallback.
- **Mocked, clearly labeled:** `HistoryScreen`'s data when no backend URL is set
  (`MockData.kt` — comment header explains why).
- **Not built:** MQTT broker integration (per the architecture diagram, this is planned
  but no broker exists yet) and a UI to configure the backend URL (currently defaults to
  null → mock data; wiring a settings field is a 10-minute follow-up once the Flask
  endpoints are confirmed live).
- **API contract:** see `docs/API_CONTRACT.md` for the full request/response shapes this
  app assumes, plus open questions for the firmware teammate.

## Notes on the network setup

`app/src/main/res/xml/network_security_config.xml` allows cleartext (plain HTTP) traffic,
which both the setup AP and the home-LAN device calls need — there's no HTTPS on an ESP32
here. If your Flask backend is also plain HTTP on your LAN, that's covered too; if it's
HTTPS, no extra config is needed for that call.
