package com.cardiokey.admin.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.cardiokey.admin.data.DeviceStatusResponse
import com.cardiokey.admin.network.NetworkModule
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

sealed interface DeviceStatusUi {
    data object Idle : DeviceStatusUi
    data object Loading : DeviceStatusUi
    data class Loaded(val status: DeviceStatusResponse) : DeviceStatusUi
    data class Failed(val message: String) : DeviceStatusUi
}

class StatusViewModel : ViewModel() {
    private val _status = MutableStateFlow<DeviceStatusUi>(DeviceStatusUi.Idle)
    val status: StateFlow<DeviceStatusUi> = _status

    fun refresh(deviceIp: String) {
        if (deviceIp.isBlank()) {
            _status.value = DeviceStatusUi.Failed("No device IP set. Finish device setup first.")
            return
        }
        _status.value = DeviceStatusUi.Loading
        viewModelScope.launch {
            _status.value = try {
                DeviceStatusUi.Loaded(NetworkModule.deviceApi(deviceIp).getStatus())
            } catch (e: Exception) {
                DeviceStatusUi.Failed(e.message ?: "Couldn't reach the device.")
            }
        }
    }
}
