package com.cardiokey.admin.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cardiokey.admin.viewmodel.DeviceStatusUi
import com.cardiokey.admin.viewmodel.StatusViewModel

@Composable
fun StatusScreen(viewModel: StatusViewModel, deviceIp: String) {
    val status by viewModel.status.collectAsState()

    LaunchedEffect(deviceIp) {
        if (deviceIp.isNotBlank()) viewModel.refresh(deviceIp)
    }

    Column(modifier = Modifier.fillMaxSize().padding(20.dp)) {
        Text("Current Status", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(4.dp))
        Text(
            if (deviceIp.isBlank()) "No device linked yet — finish Device Setup first." else "GET $deviceIp/status",
            style = MaterialTheme.typography.bodySmall
        )
        Spacer(Modifier.height(20.dp))

        when (val s = status) {
            DeviceStatusUi.Idle -> Text("Pull to refresh once a device is linked.", style = MaterialTheme.typography.bodySmall)
            DeviceStatusUi.Loading -> Row {
                CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                Spacer(Modifier.width(10.dp))
                Text("Checking device…")
            }
            is DeviceStatusUi.Loaded -> Card(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("State: ${s.status.state}", fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(6.dp))
                    Text("Wi-Fi connected: ${s.status.wifi_connected}", style = MaterialTheme.typography.bodySmall)
                }
            }
            is DeviceStatusUi.Failed -> Text(s.message, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
        }

        Spacer(Modifier.height(16.dp))
        Button(onClick = { if (deviceIp.isNotBlank()) viewModel.refresh(deviceIp) }, enabled = deviceIp.isNotBlank()) {
            Text("Refresh")
        }
    }
}
