package com.cardiokey.admin.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val CardioKeyDarkScheme = darkColorScheme(
    primary = Teal300,
    onPrimary = Ink900,
    secondary = Coral500,
    background = Ink900,
    surface = Ink800,
    surfaceVariant = Ink600,
    onBackground = Cream200,
    onSurface = Cream200,
    error = Coral600,
)

@Composable
fun CardioKeyAdminTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    // The mockup is dark-themed throughout; we use that scheme regardless of system setting
    // for this demo so the UI matches the HTML mockup exactly.
    MaterialTheme(
        colorScheme = CardioKeyDarkScheme,
        typography = MaterialTheme.typography,
        content = content
    )
}
