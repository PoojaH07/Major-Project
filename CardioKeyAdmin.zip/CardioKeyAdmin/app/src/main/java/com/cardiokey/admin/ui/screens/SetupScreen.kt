package com.cardiokey.admin.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cardiokey.admin.ui.DeviceLinkState
import com.cardiokey.admin.ui.WifiSetupState
import com.cardiokey.admin.viewmodel.SetupViewModel

@Composable
fun SetupScreen(
    viewModel: SetupViewModel,
    savedDeviceIp: String,
    onDeviceIpConfirmed: (String) -> Unit
) {
    val wifiState by viewModel.wifiState.collectAsState()
    val linkState by viewModel.linkState.collectAsState()

    var homeSsid by remember { mutableStateOf("") }
    var homePassword by remember { mutableStateOf("") }
    var deviceIpInput by remember { mutableStateOf(savedDeviceIp) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp)
    ) {
        Text("Device Setup", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(4.dp))
        Text(
            "Two stages, on two different networks — the app tags each call so it's clear which one it's making.",
            style = MaterialTheme.typography.bodySmall
        )
        Spacer(Modifier.height(20.dp))

        StageCard(title = "Stage 1 · On the CardioKey setup network") {
            Text(
                "Join your phone to the device's Wi-Fi network named CardioKey-Setup-XXXX, then tap Check below. This call goes to 192.168.4.1 — the device's temporary access point, not your home network.",
                style = MaterialTheme.typography.bodySmall
            )
            Spacer(Modifier.height(12.dp))
            when (wifiState) {
                is WifiSetupState.NotOnSetupNetwork, is WifiSetupState.Failed -> {
                    if (wifiState is WifiSetupState.Failed) {
                        ErrorText((wifiState as WifiSetupState.Failed).message)
                    }
                    Button(onClick = { viewModel.checkSetupAp() }) {
                        Icon(Icons.Default.Wifi, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Check setup network (192.168.4.1)")
                    }
                }
                WifiSetupState.CheckingSetupAp -> LoadingRow("Checking for device at 192.168.4.1…")
                WifiSetupState.ReadyToConfigure, WifiSetupState.Submitting -> {
                    OutlinedTextField(
                        value = homeSsid, onValueChange = { homeSsid = it },
                        label = { Text("Home Wi-Fi name (SSID)") },
                        singleLine = true, modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = homePassword, onValueChange = { homePassword = it },
                        label = { Text("Home Wi-Fi password") },
                        singleLine = true, modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(12.dp))
                    if (wifiState == WifiSetupState.Submitting) {
                        LoadingRow("Sending credentials to 192.168.4.1…")
                    } else {
                        Button(
                            onClick = { viewModel.submitWifiCredentials(homeSsid, homePassword) },
                            enabled = homeSsid.isNotBlank()
                        ) { Text("Send to device (POST /wifi/configure)") }
                    }
                }
                WifiSetupState.CredentialsAccepted -> {
                    SuccessText("Device accepted the credentials and is rebooting onto your home Wi-Fi. Rejoin your normal Wi-Fi on this phone, then continue to Stage 2.")
                }
            }
        }

        Spacer(Modifier.height(16.dp))

        StageCard(title = "Stage 2 · On your home network") {
            Text(
                "Once your phone is back on your normal Wi-Fi and the device has rejoined it, enter the device's IP (check your router's client list or the device's OLED) and confirm the link. This call goes to that IP on your home LAN — a different network than Stage 1.",
                style = MaterialTheme.typography.bodySmall
            )
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = deviceIpInput, onValueChange = { deviceIpInput = it },
                label = { Text("Device IP, e.g. 192.168.1.42") },
                singleLine = true, modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(12.dp))
            when (linkState) {
                DeviceLinkState.Checking -> LoadingRow("Checking device at $deviceIpInput…")
                is DeviceLinkState.Failed -> {
                    ErrorText((linkState as DeviceLinkState.Failed).message)
                    Spacer(Modifier.height(8.dp))
                    Button(
                        onClick = { viewModel.linkDeviceOnLan(deviceIpInput) },
                        enabled = deviceIpInput.isNotBlank()
                    ) { Text("Retry (GET /status)") }
                }
                DeviceLinkState.Linked -> {
                    SuccessText("Linked. The device is reachable on your home network.")
                    Spacer(Modifier.height(8.dp))
                    Button(onClick = { onDeviceIpConfirmed(deviceIpInput) }) {
                        Text("Save and continue")
                    }
                }
                DeviceLinkState.Unlinked -> {
                    Button(
                        onClick = { viewModel.linkDeviceOnLan(deviceIpInput) },
                        enabled = deviceIpInput.isNotBlank()
                    ) { Text("Confirm device on home network (GET /status)") }
                }
            }
        }
    }
}

@Composable
private fun StageCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text(title, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
            Spacer(Modifier.height(10.dp))
            content()
        }
    }
}

@Composable
private fun LoadingRow(label: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
        Spacer(Modifier.width(10.dp))
        Text(label, style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun ErrorText(message: String) {
    Text(message, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
}

@Composable
private fun SuccessText(message: String) {
    Text(message, color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall)
}
