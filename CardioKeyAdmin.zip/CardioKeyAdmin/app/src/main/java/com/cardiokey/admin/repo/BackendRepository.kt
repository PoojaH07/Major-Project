package com.cardiokey.admin.repo

import com.cardiokey.admin.data.BackendUser
import com.cardiokey.admin.data.HistoryEntry
import com.cardiokey.admin.data.MockData
import com.cardiokey.admin.network.NetworkModule

data class BackendResult<T>(val data: T, val isMock: Boolean)

/** Talks to the Flask/S3 backend for users + history. Falls back to MockData when the
 *  backend URL isn't set or the call fails — the backend team hasn't confirmed these
 *  endpoints are live yet. Every result is tagged isMock so the UI can show a badge. */
class BackendRepository {

    suspend fun getUsers(backendUrl: String?): BackendResult<List<BackendUser>> {
        if (backendUrl.isNullOrBlank()) return BackendResult(MockData.users, isMock = true)
        return try {
            BackendResult(NetworkModule.backendApi(backendUrl).getUsers(), isMock = false)
        } catch (e: Exception) {
            BackendResult(MockData.users, isMock = true)
        }
    }

    suspend fun getHistory(backendUrl: String?, userId: String?): BackendResult<List<HistoryEntry>> {
        if (backendUrl.isNullOrBlank()) return BackendResult(MockData.historyFor(userId), isMock = true)
        return try {
            BackendResult(NetworkModule.backendApi(backendUrl).getHistory(userId), isMock = false)
        } catch (e: Exception) {
            BackendResult(MockData.historyFor(userId), isMock = true)
        }
    }
}
