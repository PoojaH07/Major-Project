package com.cardiokey.admin.network

import com.cardiokey.admin.data.SetupStatusResponse
import com.cardiokey.admin.data.WifiConfigureRequest
import com.cardiokey.admin.data.WifiConfigureResponse
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST

/** Calls made ONLY while the phone is joined to the ESP32's temporary
 *  "CardioKey-Setup-XXXX" access point. Base URL: http://192.168.4.1/ */
interface SetupApi {
    @GET("status")
    suspend fun getStatus(): SetupStatusResponse

    @POST("wifi/configure")
    suspend fun configureWifi(@Body body: WifiConfigureRequest): WifiConfigureResponse
}
