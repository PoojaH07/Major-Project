package com.cardiokey.admin.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "cardiokey_prefs")

/** Persists the two things the admin has to supply by hand in this demo:
 *  the ESP32's IP once it's on the home LAN, and the Flask backend's base URL. */
class AppPreferences(private val context: Context) {

    private val deviceIpKey = stringPreferencesKey("device_ip")
    private val backendUrlKey = stringPreferencesKey("backend_url")

    val deviceIp: Flow<String?> = context.dataStore.data.map { it[deviceIpKey] }
    val backendUrl: Flow<String?> = context.dataStore.data.map { it[backendUrlKey] }

    suspend fun setDeviceIp(ip: String) {
        context.dataStore.edit { it[deviceIpKey] = ip }
    }

    suspend fun setBackendUrl(url: String) {
        context.dataStore.edit { it[backendUrlKey] = url }
    }
}
