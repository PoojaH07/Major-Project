package com.cardiokey.admin.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.HourglassEmpty
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cardiokey.admin.ui.SessionUiState
import com.cardiokey.admin.viewmodel.AuthViewModel

@Composable
fun AuthenticateScreen(viewModel: AuthViewModel, deviceIp: String) {
    val state by viewModel.state.collectAsState()

    Column(modifier = Modifier.fillMaxSize().padding(20.dp)) {
        Text("Authenticate", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(4.dp))
        Text(
            if (deviceIp.isBlank()) "No device linked yet — finish Device Setup first."
            else "Talking to device at $deviceIp",
            style = MaterialTheme.typography.bodySmall
        )
        Spacer(Modifier.height(20.dp))

        when (val s = state) {
            SessionUiState.Idle -> {
                Button(
                    onClick = { viewModel.startAuth(deviceIp) },
                    enabled = deviceIp.isNotBlank()
                ) { Text("Start authentication capture") }
            }
            SessionUiState.Starting -> StatusCard("Starting…", "Sending POST /auth/start")
            is SessionUiState.Recording -> StatusCard("Recording", "ECG + PPG capture in progress (session ${s.sessionId.take(8)}…)")
            is SessionUiState.Uploading -> StatusCard("Uploading", "Pushing the recording to S3. Polling GET /session/{id}/status…")
            is SessionUiState.UploadFailed -> {
                StatusCard("Upload failed", s.reason, isError = true)
                Spacer(Modifier.height(12.dp))
                Button(onClick = { viewModel.reset() }) { Text("Try again") }
            }
            is SessionUiState.AuthPending -> {
                // This is the important state: upload finished, but there is NO auth
                // verdict yet. We do not claim success or failure here.
                AuthPendingCard(s.sessionId)
                Spacer(Modifier.height(12.dp))
                Button(onClick = { viewModel.reset() }) { Text("Done") }
            }
            is SessionUiState.AuthResult -> {
                AuthResultCard(matched = s.matched)
                Spacer(Modifier.height(12.dp))
                Button(onClick = { viewModel.reset() }) { Text("Authenticate again") }
            }
            is SessionUiState.Error -> {
                StatusCard("Error", s.message, isError = true)
                Spacer(Modifier.height(12.dp))
                Button(onClick = { viewModel.reset() }) { Text("Dismiss") }
            }
            else -> Unit // Enroll-only state doesn't occur here
        }
    }
}

@Composable
private fun AuthPendingCard(sessionId: String) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.HourglassEmpty, contentDescription = null, tint = Color(0xFFDDB35A))
            Spacer(Modifier.width(12.dp))
            Column {
                Text("Upload succeeded — result pending", fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(4.dp))
                Text(
                    "Session ${sessionId.take(8)}… reached storage, but the device hasn't reported a match/no-match verdict. Upload success is not the same as authentication success — check History once the firmware exposes a real result.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}

@Composable
private fun AuthResultCard(matched: Boolean) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(
                if (matched) Icons.Default.CheckCircle else Icons.Default.Cancel,
                contentDescription = null,
                tint = if (matched) Color(0xFF4FD1C5) else Color(0xFFE8574B)
            )
            Spacer(Modifier.width(12.dp))
            Text(
                if (matched) "Match — authenticated" else "No match",
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}
