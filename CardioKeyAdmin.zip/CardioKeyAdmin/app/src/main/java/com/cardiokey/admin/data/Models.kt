package com.cardiokey.admin.data

import kotlinx.serialization.Serializable

// ---------- Setup-AP context (talking to 192.168.4.1) ----------

@Serializable
data class SetupStatusResponse(
    val state: String,          // "idle" | "provisioning"
    val fw_version: String = ""
)

@Serializable
data class WifiConfigureRequest(
    val ssid: String,
    val password: String
)

@Serializable
data class WifiConfigureResponse(
    val accepted: Boolean
)

// ---------- Home-LAN device context (talking to <device-ip>) ----------

@Serializable
data class DeviceStatusResponse(
    val state: String,          // "idle" | "recording" | "uploading"
    val wifi_connected: Boolean = false
)

@Serializable
data class EnrollStartRequest(
    val user_id: String
)

@Serializable
data class SessionStartResponse(
    val session_id: String,
    val state: String
)

@Serializable
data class SessionStatusResponse(
    val state: String,          // "recording" | "uploading" | "upload_ok" | "upload_failed"
    val s3_key: String? = null,
    // Not implemented on firmware yet — reserved for when a real verdict exists.
    // DeviceRepository must NEVER synthesize this from upload state.
    val auth_result: String? = null // "match" | "no_match" | null
)

// ---------- Flask/S3 backend context ----------

@Serializable
data class BackendUser(
    val user_id: String,
    val name: String,
    val enrolled_at: String
)

@Serializable
data class HistoryEntry(
    val session_id: String,
    val type: String,           // "enroll" | "auth"
    val result: String,         // "match" | "no_match" | "pending"
    val timestamp: String,
    val recording_url: String? = null
)
