package com.cardiokey.admin.data

// MOCK DATA — everything in this file is fake, standing in for the Flask backend's
// /users and /history endpoints until they're confirmed live. Any screen that reads
// from here shows a "Demo data" badge. Do not wire real device results through this file.

object MockData {

    val users = listOf(
        BackendUser("u_001", "Asha Rao", "2026-08-02T09:14:00Z"),
        BackendUser("u_002", "Wei Chen", "2026-08-15T14:02:00Z"),
        BackendUser("u_003", "Priya Nair", "2026-09-01T11:40:00Z"),
    )

    val history = listOf(
        HistoryEntry("s_1001", "enroll", "match", "2026-08-02T09:14:00Z"),
        HistoryEntry("s_1002", "auth", "match", "2026-08-03T08:02:00Z"),
        HistoryEntry("s_1003", "auth", "no_match", "2026-08-04T08:05:00Z"),
        HistoryEntry("s_1004", "auth", "pending", "2026-09-20T07:55:00Z"),
        HistoryEntry("s_1005", "enroll", "match", "2026-09-01T11:40:00Z"),
    )

    fun historyFor(userId: String?): List<HistoryEntry> =
        if (userId == null) history else history // demo data isn't keyed by user; returned as-is
}
