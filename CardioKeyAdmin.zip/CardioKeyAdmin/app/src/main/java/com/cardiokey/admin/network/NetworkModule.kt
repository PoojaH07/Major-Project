package com.cardiokey.admin.network

import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.kotlinx.serialization.asConverterFactory
import java.util.concurrent.TimeUnit

/** Builds the three separate Retrofit clients this app needs, kept apart deliberately:
 *  setup-AP calls, home-LAN device calls, and backend calls each have different hosts,
 *  different acceptable failure modes, and different timeouts. */
object NetworkModule {

    private val json = Json { ignoreUnknownKeys = true; isLenient = true }
    private val contentType = "application/json".toMediaType()

    private fun loggingClient(timeoutSeconds: Long): OkHttpClient {
        val logging = HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BASIC
        }
        return OkHttpClient.Builder()
            .connectTimeout(timeoutSeconds, TimeUnit.SECONDS)
            .readTimeout(timeoutSeconds, TimeUnit.SECONDS)
            .writeTimeout(timeoutSeconds, TimeUnit.SECONDS)
            .addInterceptor(logging)
            .build()
    }

    /** The setup AP is flaky by nature (ESP32 SoftAP under load) — short timeout so the UI
     *  can show "still connecting" and retry rather than hang. */
    fun setupApi(): SetupApi = Retrofit.Builder()
        .baseUrl("http://192.168.4.1/")
        .client(loggingClient(timeoutSeconds = 6))
        .addConverterFactory(json.asConverterFactory(contentType))
        .build()
        .create(SetupApi::class.java)

    /** Home LAN device calls: base URL depends on the IP the admin entered. */
    fun deviceApi(deviceIp: String): DeviceApi = Retrofit.Builder()
        .baseUrl("http://$deviceIp/")
        .client(loggingClient(timeoutSeconds = 10))
        .addConverterFactory(json.asConverterFactory(contentType))
        .build()
        .create(DeviceApi::class.java)

    /** Flask backend: longer timeout is fine, it's a normal internet call. */
    fun backendApi(baseUrl: String): BackendApi = Retrofit.Builder()
        .baseUrl(if (baseUrl.endsWith("/")) baseUrl else "$baseUrl/")
        .client(loggingClient(timeoutSeconds = 15))
        .addConverterFactory(json.asConverterFactory(contentType))
        .build()
        .create(BackendApi::class.java)
}
