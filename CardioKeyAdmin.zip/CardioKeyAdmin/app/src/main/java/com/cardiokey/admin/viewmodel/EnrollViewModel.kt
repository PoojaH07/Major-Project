package com.cardiokey.admin.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.cardiokey.admin.repo.DeviceRepository
import com.cardiokey.admin.ui.SessionUiState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class EnrollViewModel(
    private val repo: DeviceRepository = DeviceRepository()
) : ViewModel() {

    private val _state = MutableStateFlow<SessionUiState>(SessionUiState.Idle)
    val state: StateFlow<SessionUiState> = _state

    fun startEnroll(deviceIp: String, userId: String) {
        if (deviceIp.isBlank()) {
            _state.value = SessionUiState.Error("No device IP set. Finish device setup first.")
            return
        }
        if (userId.isBlank()) {
            _state.value = SessionUiState.Error("Enter a user ID before starting a capture.")
            return
        }
        _state.value = SessionUiState.Starting
        viewModelScope.launch {
            val result = repo.startEnroll(deviceIp, userId)
            val sessionId = result.getOrNull()
            if (sessionId == null) {
                _state.value = SessionUiState.Error(result.exceptionOrNull()?.message ?: "Failed to start enrollment.")
                return@launch
            }
            _state.value = SessionUiState.Recording(sessionId)
            _state.value = SessionUiState.Uploading(sessionId)

            val outcome = repo.awaitUploadOutcome(deviceIp, sessionId)
            val status = outcome.getOrNull()
            _state.value = when {
                status == null -> SessionUiState.Error(outcome.exceptionOrNull()?.message ?: "Upload timed out.")
                status.state == "upload_ok" -> SessionUiState.EnrollComplete(sessionId)
                else -> SessionUiState.UploadFailed(sessionId, "Device reported upload_failed.")
            }
        }
    }

    fun reset() {
        _state.value = SessionUiState.Idle
    }
}
