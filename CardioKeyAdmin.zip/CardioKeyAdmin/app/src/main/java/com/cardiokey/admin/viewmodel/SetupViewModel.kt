package com.cardiokey.admin.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.cardiokey.admin.repo.DeviceRepository
import com.cardiokey.admin.ui.DeviceLinkState
import com.cardiokey.admin.ui.WifiSetupState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class SetupViewModel(
    private val repo: DeviceRepository = DeviceRepository()
) : ViewModel() {

    private val _wifiState = MutableStateFlow<WifiSetupState>(WifiSetupState.NotOnSetupNetwork)
    val wifiState: StateFlow<WifiSetupState> = _wifiState

    private val _linkState = MutableStateFlow<DeviceLinkState>(DeviceLinkState.Unlinked)
    val linkState: StateFlow<DeviceLinkState> = _linkState

    /** Step 1: while the phone is on the ESP32's "CardioKey-Setup-XXXX" AP, confirm
     *  we can actually reach the device before showing the credential form. */
    fun checkSetupAp() {
        _wifiState.value = WifiSetupState.CheckingSetupAp
        viewModelScope.launch {
            val reachable = repo.checkSetupApReachable()
            _wifiState.value = if (reachable) {
                WifiSetupState.ReadyToConfigure
            } else {
                WifiSetupState.Failed("Can't reach the device at 192.168.4.1. Make sure your phone is joined to the CardioKey-Setup-XXXX network.")
            }
        }
    }

    /** Step 2: hand off home Wi-Fi credentials over the setup AP. */
    fun submitWifiCredentials(ssid: String, password: String) {
        _wifiState.value = WifiSetupState.Submitting
        viewModelScope.launch {
            val accepted = repo.submitWifiCredentials(ssid, password)
            _wifiState.value = if (accepted) {
                WifiSetupState.CredentialsAccepted
            } else {
                WifiSetupState.Failed("Device did not accept the credentials. Check the SSID/password and try again.")
            }
        }
    }

    /** Step 3: after the admin has manually rejoined their normal Wi-Fi and the
     *  ESP32 has (hopefully) rebooted onto it, check the device is reachable there
     *  at the IP the admin found (router admin page / device OLED). */
    fun linkDeviceOnLan(deviceIp: String) {
        _linkState.value = DeviceLinkState.Checking
        viewModelScope.launch {
            val ok = repo.checkDeviceOnLan(deviceIp)
            _linkState.value = if (ok) {
                DeviceLinkState.Linked
            } else {
                DeviceLinkState.Failed("Couldn't reach the device at $deviceIp on your home network yet. It can take up to a minute after rebooting.")
            }
        }
    }

    fun resetWifiFlow() {
        _wifiState.value = WifiSetupState.NotOnSetupNetwork
    }
}
