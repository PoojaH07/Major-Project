package com.cardiokey.admin.network

import com.cardiokey.admin.data.DeviceStatusResponse
import com.cardiokey.admin.data.EnrollStartRequest
import com.cardiokey.admin.data.SessionStartResponse
import com.cardiokey.admin.data.SessionStatusResponse
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Path

/** Calls made ONLY once both phone and ESP32 are on the normal home Wi-Fi.
 *  Base URL: http://<device-ip>/ — device-ip is entered by the admin. */
interface DeviceApi {
    @GET("status")
    suspend fun getStatus(): DeviceStatusResponse

    @POST("enroll/start")
    suspend fun startEnroll(@Body body: EnrollStartRequest): SessionStartResponse

    @POST("auth/start")
    suspend fun startAuth(): SessionStartResponse

    @GET("session/{id}/status")
    suspend fun sessionStatus(@Path("id") sessionId: String): SessionStatusResponse

    @POST("session/{id}/cancel")
    suspend fun cancelSession(@Path("id") sessionId: String)
}
