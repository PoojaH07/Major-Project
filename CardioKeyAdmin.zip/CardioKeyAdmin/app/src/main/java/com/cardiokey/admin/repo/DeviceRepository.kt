package com.cardiokey.admin.repo

import com.cardiokey.admin.data.EnrollStartRequest
import com.cardiokey.admin.data.SessionStatusResponse
import com.cardiokey.admin.data.WifiConfigureRequest
import com.cardiokey.admin.network.DeviceApi
import com.cardiokey.admin.network.SetupApi
import com.cardiokey.admin.network.NetworkModule
import kotlinx.coroutines.delay

/** Everything that talks directly to the ESP32, in either network context.
 *  This is the ONE place that reads SessionStatusResponse, specifically so the
 *  "upload success != auth success" rule is enforced in a single spot rather than
 *  re-implemented (and possibly gotten wrong) in every screen's ViewModel. */
class DeviceRepository {

    private val setupApi: SetupApi by lazy { NetworkModule.setupApi() }

    suspend fun checkSetupApReachable(): Boolean = try {
        setupApi.getStatus()
        true
    } catch (e: Exception) {
        false
    }

    suspend fun submitWifiCredentials(ssid: String, password: String): Boolean {
        return try {
            val resp = setupApi.configureWifi(WifiConfigureRequest(ssid, password))
            resp.accepted
        } catch (e: Exception) {
            false
        }
    }

    suspend fun checkDeviceOnLan(deviceIp: String): Boolean = try {
        NetworkModule.deviceApi(deviceIp).getStatus().wifi_connected
    } catch (e: Exception) {
        false
    }

    suspend fun startEnroll(deviceIp: String, userId: String): Result<String> = runCatchingApi {
        NetworkModule.deviceApi(deviceIp).startEnroll(EnrollStartRequest(userId)).session_id
    }

    suspend fun startAuth(deviceIp: String): Result<String> = runCatchingApi {
        NetworkModule.deviceApi(deviceIp).startAuth().session_id
    }

    suspend fun pollSession(deviceIp: String, sessionId: String): Result<SessionStatusResponse> =
        runCatchingApi {
            NetworkModule.deviceApi(deviceIp).sessionStatus(sessionId)
        }

    suspend fun cancelSession(deviceIp: String, sessionId: String) {
        try {
            NetworkModule.deviceApi(deviceIp).cancelSession(sessionId)
        } catch (_: Exception) {
            // best-effort; nothing meaningful to recover here for the demo
        }
    }

    /** Convenience for ViewModels: poll until a terminal upload state, with a simple
     *  fixed interval. A real implementation would back off / cap retries; this is
     *  intentionally the smallest thing that demonstrates the flow end-to-end. */
    suspend fun awaitUploadOutcome(
        deviceIp: String,
        sessionId: String,
        maxAttempts: Int = 30,
        intervalMs: Long = 1500
    ): Result<SessionStatusResponse> {
        repeat(maxAttempts) {
            val result = pollSession(deviceIp, sessionId)
            val status = result.getOrNull()
            if (status != null && (status.state == "upload_ok" || status.state == "upload_failed")) {
                return result
            }
            delay(intervalMs)
        }
        return Result.failure(Exception("Timed out waiting for upload outcome"))
    }

    private inline fun <T> runCatchingApi(block: () -> T): Result<T> = try {
        Result.success(block())
    } catch (e: Exception) {
        Result.failure(e)
    }
}
