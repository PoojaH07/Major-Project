package com.cardiokey.admin

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.MonitorHeart
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.cardiokey.admin.data.AppPreferences
import com.cardiokey.admin.ui.screens.AuthenticateScreen
import com.cardiokey.admin.ui.screens.EnrollScreen
import com.cardiokey.admin.ui.screens.HistoryScreen
import com.cardiokey.admin.ui.screens.SetupScreen
import com.cardiokey.admin.ui.screens.StatusScreen
import com.cardiokey.admin.ui.theme.CardioKeyAdminTheme
import com.cardiokey.admin.viewmodel.AuthViewModel
import com.cardiokey.admin.viewmodel.EnrollViewModel
import com.cardiokey.admin.viewmodel.HistoryViewModel
import com.cardiokey.admin.viewmodel.SetupViewModel
import com.cardiokey.admin.viewmodel.StatusViewModel
import kotlinx.coroutines.launch

private sealed class Dest(val route: String, val label: String, val icon: androidx.compose.ui.graphics.vector.ImageVector) {
    data object Setup : Dest("setup", "Setup", Icons.Default.Wifi)
    data object Enroll : Dest("enroll", "Enroll", Icons.Default.Person)
    data object Authenticate : Dest("auth", "Authenticate", Icons.Default.Fingerprint)
    data object Status : Dest("status", "Status", Icons.Default.MonitorHeart)
    data object History : Dest("history", "History", Icons.Default.History)
}

private val destinations = listOf(Dest.Setup, Dest.Enroll, Dest.Authenticate, Dest.Status, Dest.History)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            CardioKeyAdminTheme {
                CardioKeyApp()
            }
        }
    }
}

@Composable
private fun CardioKeyApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { AppPreferences(context) }
    val scope = rememberCoroutineScope()

    val deviceIp by prefs.deviceIp.collectAsState(initial = null)
    val backendUrl by prefs.backendUrl.collectAsState(initial = null)

    val navController = rememberNavController()

    val setupVm: SetupViewModel = viewModel()
    val enrollVm: EnrollViewModel = viewModel()
    val authVm: AuthViewModel = viewModel()
    val statusVm: StatusViewModel = viewModel()
    val historyVm: HistoryViewModel = viewModel()

    Scaffold(
        bottomBar = {
            val backStackEntry by navController.currentBackStackEntryAsState()
            val currentDestination = backStackEntry?.destination
            NavigationBar {
                destinations.forEach { dest ->
                    val selected = currentDestination?.hierarchy?.any { it.route == dest.route } == true
                    NavigationBarItem(
                        selected = selected,
                        onClick = {
                            navController.navigate(dest.route) {
                                popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Icon(dest.icon, contentDescription = dest.label) },
                        label = { Text(dest.label) }
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Dest.Setup.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Dest.Setup.route) {
                SetupScreen(
                    viewModel = setupVm,
                    savedDeviceIp = deviceIp.orEmpty(),
                    onDeviceIpConfirmed = { ip ->
                        scope.launch { prefs.setDeviceIp(ip) }
                    }
                )
            }
            composable(Dest.Enroll.route) {
                EnrollScreen(viewModel = enrollVm, deviceIp = deviceIp.orEmpty())
            }
            composable(Dest.Authenticate.route) {
                AuthenticateScreen(viewModel = authVm, deviceIp = deviceIp.orEmpty())
            }
            composable(Dest.Status.route) {
                StatusScreen(viewModel = statusVm, deviceIp = deviceIp.orEmpty())
            }
            composable(Dest.History.route) {
                HistoryScreen(viewModel = historyVm, backendUrl = backendUrl)
            }
        }
    }
}
