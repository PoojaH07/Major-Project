package com.cardiokey.admin.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cardiokey.admin.ui.SessionUiState
import com.cardiokey.admin.viewmodel.EnrollViewModel

@Composable
fun EnrollScreen(viewModel: EnrollViewModel, deviceIp: String) {
    val state by viewModel.state.collectAsState()
    var userId by remember { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxSize().padding(20.dp)) {
        Text("Enroll a User", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(4.dp))
        Text(
            if (deviceIp.isBlank()) "No device linked yet — finish Device Setup first."
            else "Talking to device at $deviceIp",
            style = MaterialTheme.typography.bodySmall
        )
        Spacer(Modifier.height(20.dp))

        OutlinedTextField(
            value = userId,
            onValueChange = { userId = it },
            label = { Text("User ID") },
            singleLine = true,
            enabled = state is SessionUiState.Idle || state is SessionUiState.Error,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(16.dp))

        when (val s = state) {
            SessionUiState.Idle -> {
                Button(
                    onClick = { viewModel.startEnroll(deviceIp, userId) },
                    enabled = userId.isNotBlank() && deviceIp.isNotBlank()
                ) { Text("Start enrollment capture") }
            }
            SessionUiState.Starting -> StatusCard("Starting…", "Sending POST /enroll/start")
            is SessionUiState.Recording -> StatusCard("Recording", "ECG + PPG capture in progress on the device (session ${s.sessionId.take(8)}…)")
            is SessionUiState.Uploading -> StatusCard("Uploading", "Device is pushing the recording to S3 via Flask. Polling GET /session/{id}/status…")
            is SessionUiState.UploadFailed -> {
                StatusCard("Upload failed", s.reason, isError = true)
                Spacer(Modifier.height(12.dp))
                Button(onClick = { viewModel.reset() }) { Text("Try again") }
            }
            is SessionUiState.EnrollComplete -> {
                StatusCard("Enrollment recorded", "Upload succeeded (session ${s.sessionId.take(8)}…). The recording is saved; there's nothing further to confirm for enrollment.", isSuccess = true)
                Spacer(Modifier.height(12.dp))
                Button(onClick = { viewModel.reset(); userId = "" }) { Text("Enroll another user") }
            }
            is SessionUiState.Error -> {
                StatusCard("Error", s.message, isError = true)
                Spacer(Modifier.height(12.dp))
                Button(onClick = { viewModel.reset() }) { Text("Dismiss") }
            }
            else -> Unit // Auth-only states don't occur here
        }
    }
}

@Composable
internal fun StatusCard(title: String, body: String, isError: Boolean = false, isSuccess: Boolean = false) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            if (!isError && !isSuccess) {
                CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                Spacer(Modifier.width(12.dp))
            }
            Column {
                Text(
                    title,
                    fontWeight = FontWeight.SemiBold,
                    color = when {
                        isError -> MaterialTheme.colorScheme.error
                        isSuccess -> MaterialTheme.colorScheme.primary
                        else -> MaterialTheme.colorScheme.onSurface
                    }
                )
                Spacer(Modifier.height(4.dp))
                Text(body, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}
