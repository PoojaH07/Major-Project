package com.cardiokey.admin.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.cardiokey.admin.repo.DeviceRepository
import com.cardiokey.admin.ui.SessionUiState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class AuthViewModel(
    private val repo: DeviceRepository = DeviceRepository()
) : ViewModel() {

    private val _state = MutableStateFlow<SessionUiState>(SessionUiState.Idle)
    val state: StateFlow<SessionUiState> = _state

    fun startAuth(deviceIp: String) {
        if (deviceIp.isBlank()) {
            _state.value = SessionUiState.Error("No device IP set. Finish device setup first.")
            return
        }
        _state.value = SessionUiState.Starting
        viewModelScope.launch {
            val result = repo.startAuth(deviceIp)
            val sessionId = result.getOrNull()
            if (sessionId == null) {
                _state.value = SessionUiState.Error(result.exceptionOrNull()?.message ?: "Failed to start authentication.")
                return@launch
            }
            _state.value = SessionUiState.Recording(sessionId)
            _state.value = SessionUiState.Uploading(sessionId)

            val outcome = repo.awaitUploadOutcome(deviceIp, sessionId)
            val status = outcome.getOrNull()
            when {
                status == null -> {
                    _state.value = SessionUiState.Error(outcome.exceptionOrNull()?.message ?: "Upload timed out.")
                }
                status.state == "upload_failed" -> {
                    _state.value = SessionUiState.UploadFailed(sessionId, "Device reported upload_failed.")
                }
                status.state == "upload_ok" -> {
                    // CRITICAL: upload_ok is NOT an auth result. auth_result is a separate,
                    // currently-unimplemented field. We only report AuthResult if that field
                    // is actually present — never inferred from the upload outcome.
                    when (status.auth_result) {
                        "match" -> _state.value = SessionUiState.AuthResult(sessionId, matched = true)
                        "no_match" -> _state.value = SessionUiState.AuthResult(sessionId, matched = false)
                        else -> _state.value = SessionUiState.AuthPending(sessionId)
                    }
                }
            }
        }
    }

    fun reset() {
        _state.value = SessionUiState.Idle
    }
}
