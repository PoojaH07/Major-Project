package com.cardiokey.admin.ui.theme

import androidx.compose.ui.graphics.Color

// Palette pulled from the CardioKey HTML mockup
val Ink900 = Color(0xFF0D1114)
val Ink800 = Color(0xFF12161A)
val Ink700 = Color(0xFF141A1F)
val Ink650 = Color(0xFF151A1E)
val Ink600 = Color(0xFF181D21)
val Ink550 = Color(0xFF1D242A)
val Teal500 = Color(0xFF0E8F83)
val Teal300 = Color(0xFF4FD1C5)
val Slate400 = Color(0xFF6B7480)
val Slate300 = Color(0xFF8B96A0)
val Slate500 = Color(0xFF5B6570)
val Coral600 = Color(0xFFC0392B)
val Coral500 = Color(0xFFE8574B)
val Cream100 = Color(0xFFF3F1EA)
val Cream200 = Color(0xFFEFEADF)
val Cream300 = Color(0xFFE9E4D8)
