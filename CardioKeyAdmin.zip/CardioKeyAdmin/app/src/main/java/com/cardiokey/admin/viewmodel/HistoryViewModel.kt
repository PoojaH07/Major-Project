package com.cardiokey.admin.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.cardiokey.admin.data.HistoryEntry
import com.cardiokey.admin.repo.BackendRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

data class HistoryUiState(
    val entries: List<HistoryEntry> = emptyList(),
    val isMock: Boolean = true,
    val loading: Boolean = false
)

class HistoryViewModel(
    private val repo: BackendRepository = BackendRepository()
) : ViewModel() {

    private val _state = MutableStateFlow(HistoryUiState())
    val state: StateFlow<HistoryUiState> = _state

    fun load(backendUrl: String?, userId: String? = null) {
        _state.value = _state.value.copy(loading = true)
        viewModelScope.launch {
            val result = repo.getHistory(backendUrl, userId)
            _state.value = HistoryUiState(entries = result.data, isMock = result.isMock, loading = false)
        }
    }
}
