package com.cardiokey.admin.network

import com.cardiokey.admin.data.BackendUser
import com.cardiokey.admin.data.HistoryEntry
import retrofit2.http.GET
import retrofit2.http.Query

/** Calls to the Flask/S3 backend. Base URL: configurable, e.g. http://<flask-host>:5000/
 *  NOTE: not confirmed live yet — BackendRepository falls back to MockData on failure. */
interface BackendApi {
    @GET("users")
    suspend fun getUsers(): List<BackendUser>

    @GET("history")
    suspend fun getHistory(@Query("user_id") userId: String? = null): List<HistoryEntry>
}
