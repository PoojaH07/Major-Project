package com.cardiokey.admin.ui

/** State for the two-step Wi-Fi provisioning + device-link flow on the Setup screen. */
sealed interface WifiSetupState {
    data object NotOnSetupNetwork : WifiSetupState
    data object CheckingSetupAp : WifiSetupState
    data object ReadyToConfigure : WifiSetupState
    data object Submitting : WifiSetupState
    data object CredentialsAccepted : WifiSetupState
    data class Failed(val message: String) : WifiSetupState
}

sealed interface DeviceLinkState {
    data object Unlinked : DeviceLinkState
    data object Checking : DeviceLinkState
    data object Linked : DeviceLinkState
    data class Failed(val message: String) : DeviceLinkState
}

/** State shared by Enroll and Authenticate flows: recording -> uploading -> result.
 *  AuthPending exists specifically because upload success is NOT auth success — see
 *  docs/API_CONTRACT.md. There is no code path that turns UploadSucceeded directly into
 *  a "success" for authentication. */
sealed interface SessionUiState {
    data object Idle : SessionUiState
    data object Starting : SessionUiState
    data class Recording(val sessionId: String) : SessionUiState
    data class Uploading(val sessionId: String) : SessionUiState
    data class UploadFailed(val sessionId: String, val reason: String) : SessionUiState
    data class UploadSucceeded(val sessionId: String, val s3Key: String?) : SessionUiState
    // Enroll-specific terminal state: upload succeeded and enroll doesn't need a verdict.
    data class EnrollComplete(val sessionId: String) : SessionUiState
    // Auth-specific: upload succeeded but a verdict is not yet available. This is the
    // ONLY path to a result for auth, and it currently can't resolve automatically
    // because firmware doesn't expose auth_result yet.
    data class AuthPending(val sessionId: String) : SessionUiState
    data class AuthResult(val sessionId: String, val matched: Boolean) : SessionUiState
    data class Error(val message: String) : SessionUiState
}
