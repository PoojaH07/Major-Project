package com.cardiokey.admin.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cardiokey.admin.data.HistoryEntry
import com.cardiokey.admin.viewmodel.HistoryViewModel

@Composable
fun HistoryScreen(viewModel: HistoryViewModel, backendUrl: String?) {
    val state by viewModel.state.collectAsState()

    LaunchedEffect(backendUrl) { viewModel.load(backendUrl) }

    Column(modifier = Modifier.fillMaxSize().padding(20.dp)) {
        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            Text("History & Trends", fontSize = 24.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            if (state.isMock) {
                AssistChip(onClick = {}, label = { Text("Demo data") })
            }
        }
        Spacer(Modifier.height(4.dp))
        Text(
            if (state.isMock) "Backend /history not confirmed live — showing mock data (see MockData.kt)."
            else "Live data from the backend.",
            style = MaterialTheme.typography.bodySmall
        )
        Spacer(Modifier.height(16.dp))

        if (state.loading) {
            Row {
                CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                Spacer(Modifier.width(10.dp))
                Text("Loading…")
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(state.entries) { entry -> HistoryRow(entry) }
            }
        }
    }
}

@Composable
private fun HistoryRow(entry: HistoryEntry) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(14.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    if (entry.type == "enroll") "Enrollment" else "Authentication",
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(Modifier.height(4.dp))
                Text(entry.timestamp, style = MaterialTheme.typography.bodySmall)
            }
            ResultBadge(entry.result)
        }
    }
}

@Composable
private fun ResultBadge(result: String) {
    val (label, color) = when (result) {
        "match" -> "Match" to MaterialTheme.colorScheme.primary
        "no_match" -> "No match" to MaterialTheme.colorScheme.error
        else -> "Pending" to MaterialTheme.colorScheme.onSurfaceVariant
    }
    AssistChip(onClick = {}, label = { Text(label) }, colors = AssistChipDefaults.assistChipColors(labelColor = color))
}
