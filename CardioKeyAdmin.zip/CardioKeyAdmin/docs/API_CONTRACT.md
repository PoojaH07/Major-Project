# CardioKey Admin App — API Contract (demo)

This contract covers what the Android admin app calls. Two calling contexts, deliberately kept separate in code (`SetupApi` vs `DeviceApi`) because the phone is on a *different network* for each:

## 1. Setup-AP context (phone joined `CardioKey-Setup-XXXX`, ESP32 gateway `192.168.4.1`)

Base URL: `http://192.168.4.1/`

| Method | Path | Body | Response | Notes |
|---|---|---|---|---|
| GET | `/status` | — | `{ "state": "idle"\|"provisioning", "fw_version": "..." }` | Poll to confirm we're actually talking to a CardioKey device before showing the Wi-Fi form. |
| POST | `/wifi/configure` | `{ "ssid": "...", "password": "..." }` | `{ "accepted": true }` | ESP32 accepts creds, reboots and attempts to join the home network. It does **not** confirm the join succeeded over this connection (the AP usually drops as soon as it starts trying), so the app treats "accepted" as "credentials handed off," not "connected." |

**This is the only stage where the app has a request/response cycle with the device over the
temporary AP.** Everything after this is the app polling for the device on the home network.

## 2. Home-LAN context (phone and ESP32 both on the normal Wi-Fi; device reachable at its DHCP IP)

Base URL: `http://<device-ip>/` — IP entered manually or resolved via mDNS in a future iteration; for the demo the admin types it in after checking their router or the device's OLED.

| Method | Path | Body | Response | Notes |
|---|---|---|---|---|
| GET | `/status` | — | `{ "state": "idle"\|"recording"\|"uploading", "wifi_connected": true }` | Confirms the device made it onto the home network after provisioning. |
| POST | `/enroll/start` | `{ "user_id": "..." }` | `{ "session_id": "...", "state": "recording" }` | Starts an ECG/PPG capture for enrollment. |
| POST | `/auth/start` | `{}` | `{ "session_id": "...", "state": "recording" }` | Starts a capture for authentication. |
| GET | `/session/{id}/status` | — | `{ "state": "recording"\|"uploading"\|"upload_ok"\|"upload_failed", "s3_key": "..."? }` | Polled by the app every ~2s during a session. **`upload_ok` means the recording reached S3 — it does NOT mean auth succeeded.** |
| POST | `/session/{id}/cancel` | — | `{ "cancelled": true }` | Abort a stuck session. |

## 3. Flask/S3 backend context (phone on any network with internet; talks to your backend, not the ESP32)

Base URL: configurable (e.g. `http://<flask-host>:5000/`)

| Method | Path | Response | Notes |
|---|---|---|---|
| GET | `/users` | `[{ "user_id": "...", "name": "...", "enrolled_at": "..." }]` | For the Register/Enroll screen's existing-user list. |
| GET | `/history?user_id=...` | `[{ "session_id": "...", "type": "enroll"\|"auth", "result": "match"\|"no_match"\|"pending", "timestamp": "...", "recording_url": "..." }]` | For the History screen. |
| GET | `/recordings/{id}` | binary / signed URL | Not called directly by the app in this demo; recording playback is out of scope. |

**⚠️ Not yet live:** the backend team has not confirmed `/users` and `/history` are deployed.
Until then, `BackendRepository` falls back to data in `MockData.kt`, clearly labeled
`// MOCK DATA` in code, and every mock-derived UI element shows a "Demo data" badge.

## The one rule that matters

> **S3 upload success ≠ authentication success.**

`upload_ok` from `/session/{id}/status` only tells the app the recording made it to storage.
The actual match/no-match verdict is a separate field (`auth_result`) that, in this demo,
does not exist on the device firmware yet. So the Authenticate screen's UI state machine has
an explicit `AuthPending` state that the app **cannot** resolve on its own — it sits there
until either (a) the firmware team adds a real verdict endpoint, or (b) a human checks the
history/backend record out of band. The app is not allowed to guess or infer a "success" from
the upload alone; `DeviceRepository` enforces this by keeping upload status and auth status as
two different fields that no code path collapses into one.

## Open questions for the firmware teammate

1. Does `/enroll/start` and `/auth/start` need a `Content-Type` header set explicitly, or is JSON assumed?
2. What's the actual field name for the match verdict once it exists — `auth_result`, `match`, `verdict`?
3. Is there an mDNS/`.local` hostname we can rely on instead of asking the admin to type an IP?
4. Timeout behavior: how long does `/session/{id}/status` stay in `recording` before the device gives up?
